import './style.css'
import { App } from './app.js'
new App();

